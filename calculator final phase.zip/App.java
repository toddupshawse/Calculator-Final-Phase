/**
 * Todd Maurice Upshaw
 * July 23, 2025
 * Final Calculator Project - With Menu
 * Description: Full console calculator with memory, error handling, and menu system.
 */

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Calculator calc = new Calculator();
        double result = 0.0;
        boolean running = true;

        System.out.println("Todd Maurice Upshaw - Final Calculator Project");
        System.out.println("Welcome to SmartCalc!");

        while (running) {
            printMenu();
            System.out.print("Choose an option (1–5): ");
            String choice = scanner.next();

            if (choice.equals("1")) {
                try {
                    System.out.print("Enter first number (or 'recall'): ");
                    String input1 = scanner.next();
                    double num1 = input1.equalsIgnoreCase("recall") ? getStoredValue(calc) : Double.parseDouble(input1);

                    System.out.print("Enter operator (+, -, *, /): ");
                    String operator = scanner.next();

                    System.out.print("Enter second number (or 'recall'): ");
                    String input2 = scanner.next();
                    double num2 = input2.equalsIgnoreCase("recall") ? getStoredValue(calc) : Double.parseDouble(input2);

                    if (operator.equals("+")) {
                        result = calc.add(num1, num2);
                    } else if (operator.equals("-")) {
                        result = calc.subtract(num1, num2);
                    } else if (operator.equals("*")) {
                        result = calc.multiply(num1, num2);
                    } else if (operator.equals("/")) {
                        result = calc.divide(num1, num2);
                    } else {
                        System.out.println("Invalid operator.");
                        continue;
                    }

                    System.out.println("Result: " + result);

                } catch (NumberFormatException e) {
                    System.out.println("Invalid number input.");
                } catch (ArithmeticException e) {
                    System.out.println("Math error: " + e.getMessage());
                } catch (Exception e) {
                    System.out.println("Unexpected error occurred.");
                }
            }

            else if (choice.equals("2")) {
                calc.store(result);
            }

            else if (choice.equals("3")) {
                Double recalled = calc.recall();
                if (recalled != null) {
                    System.out.println("Recalled value: " + recalled);
                }
            }

            else if (choice.equals("4")) {
                calc.clearMemory();
            }

            else if (choice.equals("5")) {
                System.out.println("Exiting SmartCalc. Goodbye!");
                running = false;
            }

            else {
                System.out.println("Invalid choice. Please select 1, 2, 3, 4, or 5.");
            }
        }

        scanner.close();
    }

    private static void printMenu() {
        System.out.println("\n=== SMARTCALC MENU ===");
        System.out.println("1. Perform a Calculation");
        System.out.println("2. Store Last Result");
        System.out.println("3. Recall Last Stored Value");
        System.out.println("4. Clear Memory");
        System.out.println("5. Exit");
    }

    private static double getStoredValue(Calculator calc) {
        Double recalled = calc.recall();
        if (recalled == null) {
            System.out.println("No value in memory. Using 0.");
            return 0.0;
        }
        return recalled;
    }
}
