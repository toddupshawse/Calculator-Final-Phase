/**
 * Todd Maurice Upshaw
 * July 23, 2025
 * Final Calculator Project - Full Functionality
 * Description: Contains arithmetic logic and memory functions using collections.
 */

import java.util.ArrayList;

public class Calculator {
    private ArrayList<Double> memory = new ArrayList<>();

    public double add(double a, double b) {
        return a + b;
    }

    public double subtract(double a, double b) {
        return a - b;
    }

    public double multiply(double a, double b) {
        return a * b;
    }

    public double divide(double a, double b) throws ArithmeticException {
        if (b == 0) throw new ArithmeticException("Cannot divide by zero.");
        return a / b;
    }

    public void store(double value) {
        memory.add(value);
        System.out.println("Value stored in memory.");
    }

    public Double recall() {
        if (memory.isEmpty()) {
            System.out.println("Memory is empty.");
            return null;
        }
        return memory.get(memory.size() - 1);
    }

    public void clearMemory() {
        memory.clear();
        System.out.println("Memory cleared.");
    }
}
